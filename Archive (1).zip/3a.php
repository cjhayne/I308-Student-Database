<?php
$con=mysqli_connect("db.soic.indiana.edu","i308s20_team46","my+sql=i308s20_team46","i308s20_team46");

// Check connection
if (mysqli_connect_error())
{echo "Failed to connect to MySQL." . mysqli_connect_error() . "<br";}


// Create SQL Statement
$sql = "SELECT f.fname, f.lname, c.title, count(c.course_id) AS times_taught
FROM faculty AS f
JOIN section_faculty AS sf ON sf.faculty_id=f.faculty_id
JOIN course_section AS cs ON cs.section_id=sf.section_id
JOIN courses AS c ON c.course_id=cs.course_id
GROUP BY c.title;";
$result = mysqli_query($con, $sql);
        
// Get Number of Rows
$num_rows = mysqli_num_rows($result);

// Display Results
if ($num_rows > 0) {
    echo "<table border='3px solid black'>";
        echo "<tr><th>First Name</th><th>Last Name</th><th>Title</th><th>Times Taught</th></tr>";
    // Output data of each row, ->fetch_assoc gives array of arrays with keys matching column names
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["fname"]."</td><td>".$row["lname"]."</td><td>".$row["title"]."</td><td>".$row["times_taught"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results <br>";
}
    
// Close Connection
mysqli_close($con);
