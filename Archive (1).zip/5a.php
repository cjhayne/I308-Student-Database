<?php
$con=mysqli_connect("db.soic.indiana.edu","i308s20_team46","my+sql=i308s20_team46","i308s20_team46");

// Check connection
if (mysqli_connect_error())
{echo "Failed to connect to MySQL." . mysqli_connect_error() . "<br";}

$var_fname = mysqli_real_escape_string($con, $_POST['form-student']);


// Create SQL Statement
$sql = "SELECT s.first_name,s.last_name, c.title, g.letter_grade
FROM students AS s
JOIN grades AS g ON g.student_id=s.id
JOIN courses AS c ON g.course_id=c.course_id
WHERE s.first_name = '$var_fname'
GROUP BY s.id, c.course_id;";

$result = mysqli_query($con, $sql);

// Get Number of Rows
$num_rows = mysqli_num_rows($result);

// Display Results
if ($num_rows > 0) {
    echo "<table border='3px solid black'>";
        echo "<tr><th scope='col' colspan='2'>First Name</th><th scope='col' colspan='2'>Last Name</th><th scope='col' colspan='2'>Title</th><th 
scope='col' colspan=2'>Letter Grade</th></tr>";
    // Output data of each row, ->fetch_assoc gives array of arrays with keys matching column names
    while($row = $result->fetch_assoc()) {
        echo
"<tr><td scope='row' colspan='2'>".$row["first_name"]."</td><td scope='row' colspan='2'>".$row["last_name"]."</td><td 
scope='row' colspan='2'>".$row["title"]."</td><td 
scope='row' colspan='2'>".$row["letter_grade"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results <br>";
}

// Close Connection
mysqli_close($con);
