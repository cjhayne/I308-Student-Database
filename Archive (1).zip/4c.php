<?php
$con=mysqli_connect("db.soic.indiana.edu","i308s20_team46","my+sql=i308s20_team46","i308s20_team46");

// Check connection
if (mysqli_connect_error())
{echo "Failed to connect to MySQL." . mysqli_connect_error() . "<br";}


// Create SQL Statement
$sql = "SELECT s.first_name, s.last_name, sem.semester, c.title, c.course_code, g.letter_grade
FROM students AS s
JOIN grades AS g ON g.student_id=s.id
JOIN courses AS c ON c.course_id= g.course_id
JOIN course_section AS cs ON cs.course_id=c.course_id
JOIN section AS sec ON cs.section_id=sec.section_id
JOIN section_semester AS ss ON ss.section_id=sec.section_id
JOIN semester AS sem ON ss.semester_id=sem.semester_id
WHERE s.id NOT IN(
	SELECT c.course_id
	FROM courses as c
	WHERE c.prereqisite_id IS NOT NULL
	)
GROUP BY s.id;

";
$result = mysqli_query($con, $sql);

// Get Number of Rows
$num_rows = mysqli_num_rows($result);

// Display Results
if ($num_rows > 0) {
    echo "<table border='3px solid black'>";
        echo "<tr><th>First Name</th><th>Last Name</th><th>Semester</th><th>Title</th><th>Course Code</th><th>Letter Grade</th></tr>";
    // Output data of each row, ->fetch_assoc gives array of arrays with keys matching column names
    while($row = $result->fetch_assoc()) {
        echo
"<tr><td>".$row["first_name"]."</td><td>".$row["last_name"]."</td><td>".$row["semester"]."</td><td>".$row["title"]."</td><td>".$row["course_code"]."</td><td>".$row[letter_grade]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results <br>";
}

// Close Connection
mysqli_close($con);



